#ifndef XMLADAPTER_H
#define XMLADAPTER_H

#include "transition.h"
#include "place.h"
#include "arrow.h"
#include "diagramitem.h"
#include "diagramscene.h"

#include "../server/petrinet.h"
#include "../server/petrinetitem.h"
#include "../server/petrinetarrow.h"
#include "../server/petrinetplace.h"
#include "../server/petrinettransition.h"

class XMLAdapter
{
public:
    XMLAdapter();

    void setScene(DiagramScene * scene)
    {myScene = scene;}
    void setSceneList(QList<DiagramScene *> * sceneList)
    {mySceneList = sceneList;}

    void setPetriNet(PetriNet * petriNet)
    {myPetriNet = petriNet;}
    void setPetriNetList(QList<PetriNet *>  *petriNetList)
    {myPetriNetList = petriNetList;}

    setServer(bool b)
    {server = b;}

    QString getName();
    QString getVersion();
    QString getAuthor();
    QString getDescription();


private:
    bool server;

    DiagramScene *myScene;
    QList<DiagramScene *> * mySceneList;

    PetriNet *myPetriNet;
    QList<PetriNet *> * myPetriNetList;




};

#endif // XMLADAPTER_H
