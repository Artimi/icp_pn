#include "xmladapter.h"

XMLAdapter::XMLAdapter()
{
}
