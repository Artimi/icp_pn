/********************************************************************************
** Form generated from reading UI file 'netinformation.ui'
**
** Created: 
**      by: Qt User Interface Compiler version 4.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NETINFORMATION_H
#define UI_NETINFORMATION_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_netinformation
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QLineEdit *LEAuthor;
    QLabel *label_2;
    QLineEdit *LEName;
    QLabel *label_3;
    QLineEdit *LEVersion;
    QLabel *label_4;
    QPlainTextEdit *TEDescription;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *netinformation)
    {
        if (netinformation->objectName().isEmpty())
            netinformation->setObjectName(QString::fromUtf8("netinformation"));
        netinformation->resize(287, 394);
        widget = new QWidget(netinformation);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 30, 258, 338));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        LEAuthor = new QLineEdit(widget);
        LEAuthor->setObjectName(QString::fromUtf8("LEAuthor"));

        gridLayout_2->addWidget(LEAuthor, 0, 1, 1, 1);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_2->addWidget(label_2, 1, 0, 1, 1);

        LEName = new QLineEdit(widget);
        LEName->setObjectName(QString::fromUtf8("LEName"));

        gridLayout_2->addWidget(LEName, 1, 1, 1, 1);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_2->addWidget(label_3, 2, 0, 1, 1);

        LEVersion = new QLineEdit(widget);
        LEVersion->setObjectName(QString::fromUtf8("LEVersion"));

        gridLayout_2->addWidget(LEVersion, 2, 1, 1, 1);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_2->addWidget(label_4, 3, 0, 1, 1);


        verticalLayout->addLayout(gridLayout_2);

        TEDescription = new QPlainTextEdit(widget);
        TEDescription->setObjectName(QString::fromUtf8("TEDescription"));
        TEDescription->setMaximumSize(QSize(256, 192));

        verticalLayout->addWidget(TEDescription);

        buttonBox = new QDialogButtonBox(widget);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(netinformation);
        QObject::connect(buttonBox, SIGNAL(accepted()), netinformation, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), netinformation, SLOT(reject()));

        QMetaObject::connectSlotsByName(netinformation);
    } // setupUi

    void retranslateUi(QDialog *netinformation)
    {
        netinformation->setWindowTitle(QApplication::translate("netinformation", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("netinformation", "Author:", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("netinformation", "Name:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("netinformation", "Version:", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("netinformation", "Description", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class netinformation: public Ui_netinformation {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NETINFORMATION_H
