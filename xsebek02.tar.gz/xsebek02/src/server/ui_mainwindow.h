/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: 
**      by: Qt User Interface Compiler version 4.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QTabWidget>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOtevrit_lokalne;
    QAction *actionUlozit_lokalne;
    QAction *actionOtevrit_ze_serveru;
    QAction *actionUlozit_na_server;
    QAction *actionMouse;
    QAction *actionPlace;
    QAction *actionTransition;
    QAction *actionArc;
    QAction *actionNov;
    QAction *actionNovakarta;
    QAction *actionKonec;
    QAction *actionZp_t;
    QAction *actionVp_ed;
    QAction *actionInformace_o_s_ti;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QTabWidget *tabWidget;
    QMenuBar *menuBar;
    QMenu *menuSoubor;
    QMenu *menuNastaven;
    QMenu *menuAbout;
    QToolBar *mainToolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(737, 461);
        MainWindow->setContextMenuPolicy(Qt::NoContextMenu);
        actionOtevrit_lokalne = new QAction(MainWindow);
        actionOtevrit_lokalne->setObjectName(QString::fromUtf8("actionOtevrit_lokalne"));
        actionUlozit_lokalne = new QAction(MainWindow);
        actionUlozit_lokalne->setObjectName(QString::fromUtf8("actionUlozit_lokalne"));
        actionOtevrit_ze_serveru = new QAction(MainWindow);
        actionOtevrit_ze_serveru->setObjectName(QString::fromUtf8("actionOtevrit_ze_serveru"));
        actionUlozit_na_server = new QAction(MainWindow);
        actionUlozit_na_server->setObjectName(QString::fromUtf8("actionUlozit_na_server"));
        actionMouse = new QAction(MainWindow);
        actionMouse->setObjectName(QString::fromUtf8("actionMouse"));
        actionMouse->setCheckable(true);
        actionPlace = new QAction(MainWindow);
        actionPlace->setObjectName(QString::fromUtf8("actionPlace"));
        actionPlace->setCheckable(true);
        actionTransition = new QAction(MainWindow);
        actionTransition->setObjectName(QString::fromUtf8("actionTransition"));
        actionTransition->setCheckable(true);
        actionArc = new QAction(MainWindow);
        actionArc->setObjectName(QString::fromUtf8("actionArc"));
        actionArc->setCheckable(true);
        actionNov = new QAction(MainWindow);
        actionNov->setObjectName(QString::fromUtf8("actionNov"));
        actionNovakarta = new QAction(MainWindow);
        actionNovakarta->setObjectName(QString::fromUtf8("actionNovakarta"));
        actionKonec = new QAction(MainWindow);
        actionKonec->setObjectName(QString::fromUtf8("actionKonec"));
        actionZp_t = new QAction(MainWindow);
        actionZp_t->setObjectName(QString::fromUtf8("actionZp_t"));
        actionVp_ed = new QAction(MainWindow);
        actionVp_ed->setObjectName(QString::fromUtf8("actionVp_ed"));
        actionInformace_o_s_ti = new QAction(MainWindow);
        actionInformace_o_s_ti->setObjectName(QString::fromUtf8("actionInformace_o_s_ti"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));

        verticalLayout->addWidget(tabWidget);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 737, 25));
        menuSoubor = new QMenu(menuBar);
        menuSoubor->setObjectName(QString::fromUtf8("menuSoubor"));
        menuNastaven = new QMenu(menuBar);
        menuNastaven->setObjectName(QString::fromUtf8("menuNastaven"));
        menuAbout = new QMenu(menuBar);
        menuAbout->setObjectName(QString::fromUtf8("menuAbout"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);

        menuBar->addAction(menuSoubor->menuAction());
        menuBar->addAction(menuNastaven->menuAction());
        menuBar->addAction(menuAbout->menuAction());
        menuSoubor->addAction(actionNov);
        menuSoubor->addAction(actionNovakarta);
        menuSoubor->addSeparator();
        menuSoubor->addAction(actionOtevrit_lokalne);
        menuSoubor->addAction(actionUlozit_lokalne);
        menuSoubor->addSeparator();
        menuSoubor->addAction(actionOtevrit_ze_serveru);
        menuSoubor->addAction(actionUlozit_na_server);
        menuSoubor->addSeparator();
        menuSoubor->addAction(actionKonec);
        menuNastaven->addAction(actionZp_t);
        menuNastaven->addAction(actionVp_ed);
        menuNastaven->addSeparator();
        menuNastaven->addAction(actionInformace_o_s_ti);
        mainToolBar->addAction(actionMouse);
        mainToolBar->addAction(actionPlace);
        mainToolBar->addAction(actionTransition);
        mainToolBar->addAction(actionArc);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        actionOtevrit_lokalne->setText(QApplication::translate("MainWindow", "Otev\305\231\303\255t lok\303\241ln\304\233", 0, QApplication::UnicodeUTF8));
        actionOtevrit_lokalne->setShortcut(QApplication::translate("MainWindow", "Ctrl+O", 0, QApplication::UnicodeUTF8));
        actionUlozit_lokalne->setText(QApplication::translate("MainWindow", "Ulo\305\276it lok\303\241ln\304\233", 0, QApplication::UnicodeUTF8));
        actionUlozit_lokalne->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        actionOtevrit_ze_serveru->setText(QApplication::translate("MainWindow", "Otev\305\231\303\255t ze serveru", 0, QApplication::UnicodeUTF8));
        actionOtevrit_ze_serveru->setShortcut(QApplication::translate("MainWindow", "Ctrl+Alt+O", 0, QApplication::UnicodeUTF8));
        actionUlozit_na_server->setText(QApplication::translate("MainWindow", "Ulo\305\276it na server", 0, QApplication::UnicodeUTF8));
        actionUlozit_na_server->setShortcut(QApplication::translate("MainWindow", "Ctrl+Alt+S", 0, QApplication::UnicodeUTF8));
        actionMouse->setText(QApplication::translate("MainWindow", "Mouse", 0, QApplication::UnicodeUTF8));
        actionMouse->setShortcut(QApplication::translate("MainWindow", "Ctrl+1", 0, QApplication::UnicodeUTF8));
        actionPlace->setText(QApplication::translate("MainWindow", "Place", 0, QApplication::UnicodeUTF8));
        actionPlace->setShortcut(QApplication::translate("MainWindow", "Ctrl+2", 0, QApplication::UnicodeUTF8));
        actionTransition->setText(QApplication::translate("MainWindow", "Transition", 0, QApplication::UnicodeUTF8));
        actionTransition->setShortcut(QApplication::translate("MainWindow", "Ctrl+3", 0, QApplication::UnicodeUTF8));
        actionArc->setText(QApplication::translate("MainWindow", "Arc", 0, QApplication::UnicodeUTF8));
        actionArc->setShortcut(QApplication::translate("MainWindow", "Ctrl+4", 0, QApplication::UnicodeUTF8));
        actionNov->setText(QApplication::translate("MainWindow", "&Nov\303\275", 0, QApplication::UnicodeUTF8));
        actionNovakarta->setText(QApplication::translate("MainWindow", "Nov\303\241 &karta", 0, QApplication::UnicodeUTF8));
        actionNovakarta->setShortcut(QApplication::translate("MainWindow", "Ctrl+N", 0, QApplication::UnicodeUTF8));
        actionKonec->setText(QApplication::translate("MainWindow", "&Konec", 0, QApplication::UnicodeUTF8));
        actionKonec->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", 0, QApplication::UnicodeUTF8));
        actionZp_t->setText(QApplication::translate("MainWindow", "Zp\304\233t", 0, QApplication::UnicodeUTF8));
        actionVp_ed->setText(QApplication::translate("MainWindow", "Vp\305\231ed", 0, QApplication::UnicodeUTF8));
        actionInformace_o_s_ti->setText(QApplication::translate("MainWindow", "Informace o s\303\255ti", 0, QApplication::UnicodeUTF8));
        menuSoubor->setTitle(QApplication::translate("MainWindow", "Soubor", 0, QApplication::UnicodeUTF8));
        menuNastaven->setTitle(QApplication::translate("MainWindow", "\303\232pravy", 0, QApplication::UnicodeUTF8));
        menuAbout->setTitle(QApplication::translate("MainWindow", "About", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
