/**
  * @file petrinetitem.cpp
  *
  * @brief Rodičovská třída všech objektů petriho sítě
  * @author xsebek02 xsimon14
  */
#include "petrinetitem.h"

PetriNetItem::PetriNetItem()
{
}
